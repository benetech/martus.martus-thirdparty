
package com.acme;

public class CheckLoader
{}
