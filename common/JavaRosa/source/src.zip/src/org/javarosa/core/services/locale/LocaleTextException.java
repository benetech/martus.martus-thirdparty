/**
 * 
 */
package org.javarosa.core.services.locale;

/**
 * @author ctsims
 *
 */
public class LocaleTextException extends RuntimeException {
	public LocaleTextException(String message) {
		super(message);
	}
}
