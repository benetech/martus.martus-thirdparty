package org.javarosa.core.services.storage;

public class StorageModifiedException extends RuntimeException {

}
