package org.javarosa.core.model.condition.pivot;

public interface Pivot {
	
}
