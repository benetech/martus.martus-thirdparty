package com.subgraph.orchid;

public interface Document {
	String getRawDocumentData();
	boolean isValidDocument();
}
