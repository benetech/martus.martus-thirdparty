package com.subgraph.orchid.directory.parsing;

public interface DocumentParsingHandler {
	void parseKeywordLine();
	void endOfDocument();
}
