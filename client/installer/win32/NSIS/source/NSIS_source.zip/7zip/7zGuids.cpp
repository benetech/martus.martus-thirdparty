// DLLExports.cpp

// #include "StdAfx.h"

#ifndef INITGUID
#define INITGUID
#endif
#include <objbase.h>
#include <initguid.h>
#include "../Platform.h"
#include "7zip/ICoder.h"
#include "7zip/Compress/LZ/IMatchFinder.h"
